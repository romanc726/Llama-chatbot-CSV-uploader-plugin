// debug.js
if (typeof csvUploaderFiles !== 'undefined') {
    console.log('Files in answers folder:', csvUploaderFiles.files);
}
